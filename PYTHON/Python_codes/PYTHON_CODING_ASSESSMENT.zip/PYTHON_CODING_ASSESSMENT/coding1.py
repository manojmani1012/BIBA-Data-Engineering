#Coding Assesment:
# 1.Explain Python Module with examples a Import module in Python Renaming the Python module
#Python module  is a file containing Python definitions and statements. The file name is the module name with the suffix .py.
# Modules allow you to organize your code into separate files, making it easier to manage and maintain. 
# we can use the import statement to include a module in your Python script or interactive session. 
 
#we can save this file as module and importing into the another file to use these functions
def add(x, y):
    return (x+y)
 
def subtract(x, y):
    return (x-y)

def multi(x,y):
    return x*y

def divi(x,y):
    return x/y

def modulo(x,y):
    return x%y

 
 
 
 
 
 
 
 
 
 
 
 
 
#2.Explain Pandas and numpy using Examples in PYTHON