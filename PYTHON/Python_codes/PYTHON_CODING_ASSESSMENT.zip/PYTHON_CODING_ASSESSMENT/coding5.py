import calendar
ca = calendar.month(2023, 11)
print("Here is the calendar:")
print(ca)


import time                     # This is required to include time module.
t=time.localtime(time.time())     
print(t)

t1=time.asctime(time.localtime(time.time()))
print(t1)






 
