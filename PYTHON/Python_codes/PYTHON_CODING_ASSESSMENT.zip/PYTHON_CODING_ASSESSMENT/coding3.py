#use math functions by importing math
import math
#from math import *  - same as import math

print("Square root :",math.sqrt(25))                                              # using square root(sqrt) 

print("Pi value:",math.pi)                                                     # using pi 
 
print("Degree:",math.degrees(5))                                              # 5 radians
 
print("Radians:",math.radians(55))                                              # 55 degrees
 
print("Sin value:",math.sin(2))                                                    # Sine of 2 radians
 
print("Cos value:",math.cos(0.5))                                                   # cos of 0.5 radians
 
print("Tan value:",math.tan(0.25))                                                   # tan of 0.25 radians
 
print("Factorial value:",math.factorial(5))                                                 #5-120