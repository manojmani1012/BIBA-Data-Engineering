#creating own module

def greet(name):
    print(f"Hello, {name}!")
    
def func(shop):
    print(f"The {shop} is closed")

def func1(when):
    print(f"It will open on {when}")
