#importing the own module in this file
import coding6 as val    #renaming as val
val.greet("sachin")
val.func("Coffee shop")
val.func1("Monday")