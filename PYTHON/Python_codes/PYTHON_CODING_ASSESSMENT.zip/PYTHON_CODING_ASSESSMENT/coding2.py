import coding1
print(coding1.add(10,785))
print(coding1.subtract(1000,5))
print(coding1.multi(10,15))
print(coding1.divi(10,2))
print(coding1.modulo(5,3))